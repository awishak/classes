-- Worksheets: one sheet per student per assignment, one row per answer.
--
-- Run in the class site's Supabase project, the one the decks migrations ran
-- in. Students sign in with Supabase Auth, so the rules read who is asking
-- off the token (worksheet_viewer()) and let them touch only their own rows.
-- The instructor reads through the service role for now; no host rules yet.
--
-- The rules in words:
--   A student sees, starts and submits their own sheet, and never deletes it.
--   A student adds and removes their own answers. Nothing else changes an
--   answer: a verdict is the instructor's, written later with the service key.
--   An answer is never blank and never longer than a paragraph.

create table if not exists worksheet_sheets (
  id            uuid primary key default gen_random_uuid(),
  worksheet_key text not null,
  group_key     text not null,
  viewer_id     text not null,
  started_at    timestamptz not null default now(),
  submitted_at  timestamptz,
  unique (worksheet_key, group_key, viewer_id),
  check (viewer_id = lower(viewer_id))
);
comment on table worksheet_sheets is 'One student''s copy of one worksheet in one class. viewer_id is the sign-in email, lowercased.';

create table if not exists worksheet_answers (
  id         uuid primary key default gen_random_uuid(),
  sheet_id   uuid not null references worksheet_sheets(id) on delete cascade,
  field      text not null check (field ~ '^[a-z]+(:[a-z]+(>[a-z]+)?)?$'),
  value      text not null check (length(btrim(value)) between 1 and 500),
  position   int  not null default 0,
  created_at timestamptz not null default now(),
  verdict    text check (verdict in ('approved', 'denied'))
);
comment on column worksheet_answers.field is 'card:<node>, line:<from>><to>, or a box key (notice, think, wonder).';
create index if not exists worksheet_answers_sheet on worksheet_answers (sheet_id);
create index if not exists worksheet_sheets_group on worksheet_sheets (worksheet_key, group_key);

create or replace function worksheet_viewer() returns text
language sql stable as $$
  select lower(coalesce(auth.jwt() ->> 'email', ''))
$$;

create or replace function worksheet_owns(s uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from worksheet_sheets w where w.id = s and w.viewer_id = worksheet_viewer())
$$;

alter table worksheet_sheets  enable row level security;
alter table worksheet_answers enable row level security;

drop policy if exists worksheet_sheets_see on worksheet_sheets;
create policy worksheet_sheets_see on worksheet_sheets for select
  using (viewer_id = worksheet_viewer());
drop policy if exists worksheet_sheets_start on worksheet_sheets;
create policy worksheet_sheets_start on worksheet_sheets for insert
  with check (viewer_id = worksheet_viewer() and worksheet_viewer() <> '');
drop policy if exists worksheet_sheets_submit on worksheet_sheets;
create policy worksheet_sheets_submit on worksheet_sheets for update
  using (viewer_id = worksheet_viewer()) with check (viewer_id = worksheet_viewer());

drop policy if exists worksheet_answers_see on worksheet_answers;
create policy worksheet_answers_see on worksheet_answers for select
  using (worksheet_owns(sheet_id));
drop policy if exists worksheet_answers_add on worksheet_answers;
create policy worksheet_answers_add on worksheet_answers for insert
  with check (worksheet_owns(sheet_id) and verdict is null);
drop policy if exists worksheet_answers_drop on worksheet_answers;
create policy worksheet_answers_drop on worksheet_answers for delete
  using (worksheet_owns(sheet_id));

-- A student can change which sheet they are on or its start only through the
-- rows above; the trigger holds worksheet_key, group_key and viewer_id still.
create or replace function worksheet_sheets_hold() returns trigger
language plpgsql as $$
begin
  new.worksheet_key := old.worksheet_key;
  new.group_key := old.group_key;
  new.viewer_id := old.viewer_id;
  new.started_at := old.started_at;
  return new;
end $$;
drop trigger if exists worksheet_sheets_hold on worksheet_sheets;
create trigger worksheet_sheets_hold before update on worksheet_sheets
  for each row execute function worksheet_sheets_hold();
