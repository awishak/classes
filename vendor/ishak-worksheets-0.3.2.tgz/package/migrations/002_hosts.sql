-- Hosts: the instructor reads every sheet in the class and writes verdicts.
--
-- Run after 001, in the same project. A host is an email in worksheet_hosts,
-- the way decks keeps deck_hosts. The host's own token does the reading and
-- the verdict writing through these rules; no service key reaches a browser.
--
-- The rules in words:
--   A host sees every sheet and every answer.
--   A host changes only an answer's verdict. The trigger holds the rest
--   still, so a verdict can never rewrite what a student wrote.
--   Students see their own rows as before. Verdicts stay off their screens
--   until a release, which is a later migration.

create table if not exists worksheet_hosts (
  email text primary key check (email = lower(email))
);
alter table worksheet_hosts enable row level security;   -- no policies: read only through worksheet_is_host()

insert into worksheet_hosts (email) values ('andrewishak@gmail.com'), ('aishak@scu.edu')
  on conflict do nothing;

create or replace function worksheet_is_host() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from worksheet_hosts h where h.email = worksheet_viewer())
$$;

drop policy if exists worksheet_sheets_host on worksheet_sheets;
create policy worksheet_sheets_host on worksheet_sheets for select
  using (worksheet_is_host());

drop policy if exists worksheet_answers_host_see on worksheet_answers;
create policy worksheet_answers_host_see on worksheet_answers for select
  using (worksheet_is_host());
drop policy if exists worksheet_answers_verdict on worksheet_answers;
create policy worksheet_answers_verdict on worksheet_answers for update
  using (worksheet_is_host()) with check (worksheet_is_host());

create or replace function worksheet_answers_hold() returns trigger
language plpgsql as $$
begin
  new.sheet_id := old.sheet_id;
  new.field := old.field;
  new.value := old.value;
  new.position := old.position;
  new.created_at := old.created_at;
  return new;
end $$;
drop trigger if exists worksheet_answers_hold on worksheet_answers;
create trigger worksheet_answers_hold before update on worksheet_answers
  for each row execute function worksheet_answers_hold();
