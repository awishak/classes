# Worksheets

**A visual, interactive worksheet that students fill in. Its own project, like
decks and games, incorporated into classes first and other places later.**

Started 2026-09-24 in a Claude Code session on Andrew's Mac. This brief is the
handoff: everything decided, everything open, and where the work sits. A new
session on any machine should read this first.

## What it is, plainly

A beautiful page with things to fill in. The first one is a stakeholder map of
sports communication, adapted from Billings, Butterworth and Turman. Cards for
each stakeholder, no lines at first. A student clicks one card, then another,
and a line runs from the first to the second. A question appears in Andrew's
words: "What do Athletes provide or signal to Fans?" They answer, the answer
moves along the line, and they go on until they have enough lines.

Some worksheets confirm a right answer. This first one does not; they fill it
in and that is it.

## Decisions so far

- **Own repo.** `@ishak/worksheets`, installed into classes by git tag the way
  decks is (`"@ishak/worksheets": "github:awishak/worksheets#v0.1.0"`). Cut a
  tag, then install the tag by name in classes. `prepare` builds `dist/` on
  install, so dist is not committed.
- **Own tables, not the class blob.** Decided 2026-09-24 when the question was
  how to guarantee nothing is lost over a weekend. The class store is one JSON
  row per class merged on every save, the thing that once ate a day of
  planning. The sheet keeps `worksheet_sheets` (one per student per
  assignment) and `worksheet_answers` (one row per chip) in the classes
  Supabase project, written from the browser as the signed-in student through
  RLS, the decks pattern. `migrations/001_init.sql`. Every write asks for the
  row back; an empty return is an error, never a tick.
- **A save queue.** `src/queue.js`. Every add and remove goes into
  localStorage first, then out in order; a failed send retries with back-off
  to thirty seconds; a reload replays what is left before loading; a dead
  token stops the retries and says so. Pending chips are dimmed.
- **In classes**, `/<class>/worksheets/<key>` (`src/engine/WorksheetPage.jsx`)
  signs the sheet in as the student off the roster. The instructor gets a
  sheet under their own email, for trying it. The My Work item is an
  assignment in the class store whose details link points at that address.
- **First run: COMM 118, Fall 2026**, the AFL Grand Final, played Friday
  night Pacific, 2026-09-25.
- **Chips everywhere.** Cards, connections and the three boxes all take
  several answers, Enter adds another. The day-one field types (text, pick
  one, pick many, number) are still the plan for other sheets.
- **Solo, on a laptop.** Part of COMM 3 weekly challenge #1, but treated as its
  own assignment for now.
- **Save after every answer.** Each answer is clickable to edit, with a tick to
  save. This matters: a day of COMM 3 planning once vanished silently.
- **Editable after submitting.** A sheet is "started" until everything is
  filled in, then it says, in his words: "You have everything filled in. Ready
  to submit?"
- **A worksheet is a template.** Each assignment of it gets its own student
  copies; one copy per student per assignment.
- **Similar answers match.** Ignore case, whitespace and trailing punctuation
  when deciding two students wrote the same thing.
- **Instructor view is a spreadsheet.** One row per student, one column per
  answer. Green check approves, red x denies, and a verdict on one answer
  applies to every identical answer. Students see the verdict. He can also page
  through the sheets one at a time as the student saw them. No export.
- **The look is the class look.** Outfit, the Clean theme's greys and
  hairlines, cards at radius 16 on the sunk surface, the class accent for
  anything you can press. Andrew rejected a dark stadium look, a serif ivory
  look, and an invented gold accent. Do not guess at a look; use the class
  site's (`~/.claude/DESIGN.md`, `classes/src/engine/tokens.js`, `themes.js`).
- **Cards, not circles.** Rounded squares. The guide line says "card".
- **One direction per line.** Athletes then Fans gives Athletes to Fans only.
  The other way is its own line, drawn by clicking the other way round.
- **Several answers per line.** Chips in the question card; Enter adds another.
- **Money is green with a dollar sign.** The words: money, cash, salary,
  salaries, sponsorship, sponsorships, ticket sales.
- **Answers flow.** Each saved word moves along the line and fades out as it
  reaches the card, then comes round again. Speed scales with line length.
- **Lines never pass through a card.** A gentle bend is tried first; if every
  bend crosses a card, a grid walk goes round and is smoothed. All 156 ordered
  pairs of the current layout are checked clean.
- **Guide lines, his words:** "Click a card." Then: "Now, either click the same
  card to fill it in, or click a different card to define the relationship
  between the two."
- **Hint on every card:** a one-sentence definition, with examples only where
  his sketch had them. Athletes carries his sentence. The other twelve are
  Claude's drafts, in `src/stakeholder-map.html`, for him to edit.
- **About fifteen lines** make a finished sheet. Placeholder count.
- **No words he did not write** on any screen or mockup. See the
  `never-invent-his-words` note. The definitions are the one exception, and he
  asked for them.

## Open

- **The saving words are placeholders.** Loading…, Saving…, Saved, "Not saved
  yet. Trying again.", "Signed out. Sign in again to keep saving.", "Could not
  load your sheet. Reload to try again." In `src/sheet.js`, `STATUS`. Ask
  Andrew for his.
- **Release and thumbs up.** Decided 2026-09-24: verdicts are on connections
  only, and students see nothing of them until Andrew releases the worksheet
  to the class. After a release, students see every answer to every question
  and can give a thumbs up, once per answer. Not built. Needs a release row
  per worksheet per class, a likes table, and the student sheet reading other
  students' rows only after the release, in RLS.
- **No student Worksheets tab.** Andrew hands students the address on an
  assignment. Later Games becomes Activities and worksheets are listed there.
- Words on the instructor pages are Claude's for now: "started", "submitted",
  "not started", "Open sheet", "Previous", "Next", "Close", "No sheets yet."
- "players" in step 1 is the Billings, Butterworth and Turman word, used
  because Andrew did not have one. Easy to change.
- Which pairs count, if any are wrong. Right now any pair is allowed.
- Whether a saved answer should also sit still beside the line, readable at
  rest, with only a copy moving.
- Illustrations for the cards. He wants something Miyazaki-like, not clip art.
  Not produced; cards leave room for a picture each.
- Whether the sheet is paper or the student's own theme.
- How the worksheet lands in classes: as a package export like games, wired to
  the store, with a My Work card.

## Done 2026-09-24, after the brief was first written

Thick ring on each card (ring starts a connection, middle fills the card in),
instructions in his words in one collapsible, three boxes below (Observations,
Opinions, Questions, five each, chips), five progress cards, four cards grayed
out for now (Activist Groups, Sportsbooks, Parents, Academic Institutions),
credit line, title, and the package, store, queue and classes wiring above.

## Instructor side, 2026-09-24 evening

`WorksheetReview` (`src/review.jsx`): one row per student, one column per
connection, chips in the cells, a green check or red x on each. A verdict
lands on every identical answer in that column (`sameKey` in
`src/host-store.js`: case, whitespace and trailing punctuation ignored).
Cards and the three boxes sit to the right, read only. Open sheet mounts the
student's sheet in the sheet's `readOnly` mode. `migrations/002_hosts.sql`
names the hosts and lets a host read every row and change only a verdict. In
classes: `/<class>/worksheets` behind the instructor gate
(`src/engine/WorksheetsPage.jsx`), linked beside Games on the class page.

## Next

1. Run `migrations/002_hosts.sql` in the classes Supabase project.
2. His words for the saving line and the instructor-page words above.
3. Release and thumbs up.

## Where things are

- `src/sheet.js`: the sheet, CSS and markup and all, scoped under `.ws`.
  `mountSheet(root, {store})`. `memoryStore()` for the dev page.
- `src/supabase-store.js`, `src/queue.js`, `src/index.js` (the React
  `Worksheet` component classes uses), `migrations/001_init.sql`,
  `scripts/smoke.mjs` (jsdom; `npm test`). `npm run dev` opens the dev page.
- `studies/`: the earlier rounds, kept as the record of what was rejected and
  why. `00-sketch.png` is his drawing. 01 three static layouts. 02 the motion
  studies and the research. 03 the first working blank map. 04 the dark
  stadium look (rejected: dark ground). 05 the ivory serif look (rejected:
  guessing at the UI).
- Published artifacts, on his claude.ai account:
  - Three layouts: https://claude.ai/artifact/PVgTDnr6Z9Qn4q4twHmMD2
  - Motion studies: https://claude.ai/artifact/DdhEv6M8L6wXdY8es5o5Sa
  - Blank map: https://claude.ai/artifact/KwGHTkmCAV8BJJiJ4bHJbf
  - Floodlight: https://claude.ai/artifact/Lp9vDvABfUtQrE6JyfBeyz
  - Paper: https://claude.ai/artifact/59QwMxQHLDeXHraFUPgpSR
  - Class map, current: https://claude.ai/artifact/VtH5nc45Q1PLLL9dekUNP3

## Research behind the lines

- Holten et al. 2011: tapered edges read direction best; animated edges the
  other strong option.
- Romat et al. 2018 (Microsoft Research, CHI): animated edge textures; edge as
  tunnel, node as emitter; motion reads as transfer.
- Flow-map practice: opposite flows bow apart so a pair reads as two arcs.
- Dash-offset animation on many SVG paths is costly; move a shape along a path
  instead. Fifteen lines is fine either way.
