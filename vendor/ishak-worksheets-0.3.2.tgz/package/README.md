# worksheets

Visual, interactive worksheets students fill in. Its own project, used first in
[classes](https://github.com/awishak/classes).

Start with `BRIEF.md`. `npm install`, then `npm run dev` for the sheet on a
store that forgets, `npm test` for the jsdom smoke run, `npm run build` for
`dist/`. Earlier rounds are in `studies/`.
